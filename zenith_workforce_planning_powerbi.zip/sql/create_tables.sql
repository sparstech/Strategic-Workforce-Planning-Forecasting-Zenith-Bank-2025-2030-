
-- Create tables
CREATE TABLE employee_master (
    emp_id INT PRIMARY KEY,
    department VARCHAR(50),
    grade VARCHAR(30),
    role VARCHAR(30),
    age INT,
    hire_year INT
);

CREATE TABLE skills_matrix (
    emp_id INT,
    skill VARCHAR(50),
    proficiency_level INT
);

CREATE TABLE role_requirements (
    department VARCHAR(50),
    role VARCHAR(30),
    skill VARCHAR(50),
    required_level INT
);

CREATE TABLE headcount_targets (
    department VARCHAR(50),
    year INT,
    target_headcount INT
);

CREATE TABLE turnover_history (
    department VARCHAR(50),
    year INT,
    leavers_count INT
);
